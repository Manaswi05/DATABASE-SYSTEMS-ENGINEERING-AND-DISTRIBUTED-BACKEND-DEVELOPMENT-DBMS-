# Logistics Global — React

This is a React (Vite) port of the original single-file `Website.html`. It reproduces
the exact same look, layout, copy, and interactive behavior — login/signup screen,
home page with hero + tracking bar, live Leaflet map with real geocoding via
Nominatim, the 5 service pages (Air / Ocean / Warehouse / Last Mile / Sea Port),
the instant quote calculator, and the multi-step "create shipment" booking modal.

## Getting started

```bash
npm install
npm run dev
```

Then open the printed local URL (usually http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview
```

## Notes on the port

- Tailwind is loaded the same way as the original file (the Tailwind CDN script,
  in `index.html`), so no Tailwind build config is needed.
- Icons use the `lucide-react` package instead of the `data-lucide` + UMD script
  approach, since that maps naturally onto React components.
- The Leaflet map and the live Nominatim geocoding call are ported into a
  `TrackingMap` component using the same endpoints and logic as the original
  `updateMapLocation()` function.
- The in-memory `shipmentDatabase` (used by the booking wizard and the tracker)
  is kept as a `useRef` object in `App.jsx`, mirroring the original global
  JS object — it resets on page refresh, exactly like the original.
