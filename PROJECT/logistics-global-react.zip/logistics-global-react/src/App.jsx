import { useRef, useState } from 'react'
import AuthView from './components/AuthView.jsx'
import HomeView from './components/HomeView.jsx'
import BookingModal from './components/BookingModal.jsx'
import ServicePage from './components/ServicePage.jsx'
import SeaPortPage from './components/SeaPortPage.jsx'

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoginMode, setIsLoginMode] = useState(true)
  const [currentView, setCurrentView] = useState('home') // 'home' | 'service-air' | 'service-ocean' | 'service-warehouse' | 'service-truck' | 'service-port'
  const [bookingOpen, setBookingOpen] = useState(false)

  // Acts as the in-memory "shipmentDatabase" object from the original script
  const shipmentDatabase = useRef({})

  function handleAuth() {
    setIsAuthenticated(true)
  }

  function toggleAuthMode() {
    setIsLoginMode((v) => !v)
  }

  function logout() {
    setIsAuthenticated(false)
    setIsLoginMode(true)
  }

  function showHome() {
    setCurrentView('home')
    window.scrollTo(0, 0)
  }

  function showService(id) {
    setCurrentView(id)
    window.scrollTo(0, 0)
  }

  function openBookingModal() {
    setBookingOpen(true)
  }

  function closeBookingModal() {
    setBookingOpen(false)
  }

  function finishBooking(id, data) {
    shipmentDatabase.current[id] = data
  }

  if (!isAuthenticated) {
    return (
      <AuthView isLoginMode={isLoginMode} onToggleMode={toggleAuthMode} onAuth={handleAuth} />
    )
  }

  return (
    <>
      {currentView === 'home' && (
        <HomeView
          onLogout={logout}
          onHome={showHome}
          onShowService={showService}
          onOpenBookingModal={openBookingModal}
          shipmentDatabase={shipmentDatabase}
        />
      )}

      {currentView === 'service-port' && <SeaPortPage onHome={showHome} />}

      {['service-air', 'service-ocean', 'service-warehouse', 'service-truck'].includes(
        currentView
      ) && <ServicePage id={currentView} onHome={showHome} />}

      {bookingOpen && (
        <BookingModal onClose={closeBookingModal} onFinish={finishBooking} />
      )}
    </>
  )
}
