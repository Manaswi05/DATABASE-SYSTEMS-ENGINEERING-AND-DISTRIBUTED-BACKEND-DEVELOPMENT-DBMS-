export const services = {
  'service-air': {
    heroClass: 'hero-air',
    heroTitle: 'AIR FREIGHT',
    navTitle: 'Air Freight',
    heading: 'Speed and Reliability',
    paragraph:
      'When time is critical, our Air Freight services ensure your cargo reaches its destination safely and on schedule. We partner with major commercial airlines and dedicated cargo carriers.',
    gallery: [
      { src: 'https://images.unsplash.com/photo-1520607162513-77705e685727?q=80&w=2070&auto=format&fit=crop', alt: 'Cargo Loading' },
      { src: 'https://images.unsplash.com/photo-1517404215738-15263e9f9178?q=80&w=2070&auto=format&fit=crop', alt: 'Goods Handling' },
      { src: 'https://images.unsplash.com/photo-1483304528321-0674f0040030?q=80&w=2074&auto=format&fit=crop', alt: 'Plane Takeoff' },
    ],
    partnersTitle: 'Strategic Partners',
    partners: [
      { name: 'Emirates SkyCargo', color: 'text-red-600' },
      { name: 'FedEx Aviation', color: 'text-purple-800' },
      { name: 'DHL Aviation', color: 'text-yellow-600' },
    ],
  },
  'service-ocean': {
    heroClass: 'hero-ocean',
    heroTitle: 'OCEAN CARGO',
    navTitle: 'Ocean Cargo',
    heading: 'Connecting Continents',
    paragraph:
      'Cost-effective shipping solutions for large volume international trade via FCL and LCL.',
    gallery: [
      { src: 'https://images.unsplash.com/photo-1554254639-963a7940e794?q=80&w=2072&auto=format&fit=crop', alt: 'Container Ship' },
      { src: 'https://images.unsplash.com/photo-1605745341112-85968b19335b?q=80&w=2070&auto=format&fit=crop', alt: 'Port Cranes' },
      { src: 'https://images.unsplash.com/photo-1585713181935-d5f622cc2415?q=80&w=2131&auto=format&fit=crop', alt: 'Containers Stacked' },
    ],
    partnersTitle: 'Shipping Alliances',
    partners: [
      { name: 'MAERSK', color: 'text-blue-400' },
      { name: 'MSC', color: 'text-yellow-500' },
      { name: 'COSCO', color: 'text-blue-900' },
    ],
  },
  'service-warehouse': {
    heroClass: 'hero-warehouse',
    heroTitle: 'WAREHOUSING',
    navTitle: 'Warehousing',
    heading: 'Smart Storage',
    paragraph:
      'Advanced inventory management and secure storage solutions for your supply chain.',
    gallery: [
      { src: 'https://images.unsplash.com/photo-1553413077-190dd305871c?q=80&w=2070&auto=format&fit=crop', alt: 'Warehouse Interior' },
      { src: 'https://images.unsplash.com/photo-1616401784845-180882ba9ba8?q=80&w=2072&auto=format&fit=crop', alt: 'Forklift Operation' },
      { src: 'https://images.unsplash.com/photo-1565891741441-64926e441838?q=80&w=2070&auto=format&fit=crop', alt: 'Inventory Scan' },
    ],
    partnersTitle: 'Facility Partners',
    partners: [
      { name: 'PROLOGIS', color: 'text-green-700' },
      { name: 'Amazon Freight', color: 'text-orange-600' },
      { name: 'DHL Supply Chain', color: 'text-red-700' },
    ],
  },
  'service-truck': {
    heroClass: 'hero-truck',
    heroTitle: 'LAST MILE',
    navTitle: 'Last Mile',
    heading: 'Precision Delivery',
    paragraph:
      'Ensuring goods arrive at their final destination safely and on time, anywhere in the city.',
    gallery: [
      { src: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?q=80&w=2070&auto=format&fit=crop', alt: 'Delivery Truck' },
      { src: 'https://images.unsplash.com/photo-1620455519807-8898b96495db?q=80&w=2148&auto=format&fit=crop', alt: 'Urban Van' },
      { src: 'https://images.unsplash.com/photo-1556740738-b6a63e27c4df?q=80&w=2075&auto=format&fit=crop', alt: 'Package Handoff' },
    ],
    partnersTitle: 'Delivery Network',
    partners: [
      { name: 'UPS', color: 'text-yellow-900' },
      { name: 'FedEx Ground', color: 'text-purple-700' },
      { name: 'Blue Dart', color: 'text-blue-600' },
    ],
  },
}
