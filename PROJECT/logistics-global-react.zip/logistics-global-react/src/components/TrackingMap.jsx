import { useEffect, useRef, useState } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { Map, Satellite, MapPin } from 'lucide-react'

// Leaflet's default marker icon paths break under bundlers like Vite,
// so point them at the bundled asset URLs.
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png'
import markerIcon from 'leaflet/dist/images/marker-icon.png'
import markerShadow from 'leaflet/dist/images/marker-shadow.png'

delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
})

export default function TrackingMap({ address }) {
  const containerRef = useRef(null)
  const mapRef = useRef(null)
  const markerRef = useRef(null)

  const [liveAddress, setLiveAddress] = useState('Searching Satellite...')
  const [lat, setLat] = useState('--')
  const [lng, setLng] = useState('--')

  // Initialize the map once, centered on India (same default as the original)
  useEffect(() => {
    if (!mapRef.current && containerRef.current) {
      mapRef.current = L.map(containerRef.current).setView([20.5937, 78.9629], 5)
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(mapRef.current)
    }
    return () => {
      if (mapRef.current) {
        mapRef.current.remove()
        mapRef.current = null
        markerRef.current = null
      }
    }
  }, [])

  // Geocode the tracking location and update the marker, same logic as updateMapLocation()
  useEffect(() => {
    if (!address) return
    let cancelled = false
    setLiveAddress('Searching Satellite...')

    async function updateMapLocation() {
      try {
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}`
        )
        const data = await response.json()
        if (cancelled) return

        if (data && data.length > 0) {
          const latVal = parseFloat(data[0].lat)
          const lonVal = parseFloat(data[0].lon)
          const displayName = data[0].display_name

          setLiveAddress(displayName.split(',').slice(0, 3).join(','))
          setLat(latVal.toFixed(4))
          setLng(lonVal.toFixed(4))

          if (mapRef.current) {
            mapRef.current.setView([latVal, lonVal], 13)
            if (markerRef.current) {
              markerRef.current.setLatLng([latVal, lonVal])
            } else {
              markerRef.current = L.marker([latVal, lonVal]).addTo(mapRef.current)
            }
            markerRef.current.bindPopup(`<b>Current Location</b><br>${displayName}`).openPopup()
          }
        } else {
          setLiveAddress('Signal Lost (Location Not Found)')
        }
      } catch (error) {
        console.error('Geocoding error:', error)
        if (!cancelled) setLiveAddress('Connection Error')
      }
    }

    updateMapLocation()
    return () => {
      cancelled = true
    }
  }, [address])

  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden mb-8 relative">
      <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
        <h4 className="font-bold text-slate-800 flex items-center gap-2">
          <Map className="text-blue-600 w-5 h-5" /> Live GPS Tracking
        </h4>
        <div className="text-xs text-slate-500 flex items-center gap-1">
          <Satellite className="w-3 h-3 text-green-500 animate-pulse" /> Real-time Signal
        </div>
      </div>
      <div ref={containerRef} className="h-96 w-full z-0"></div>
      <div className="absolute bottom-4 left-4 z-[400] bg-white/95 backdrop-blur px-4 py-3 rounded-lg shadow-xl border border-slate-200 max-w-xs">
        <div className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">
          Current Coordinates
        </div>
        <div className="font-bold text-slate-800 text-sm flex items-center gap-1 mb-1">
          <MapPin className="w-4 h-4 text-red-500" /> <span>{liveAddress}</span>
        </div>
        <div className="text-xs text-slate-600 flex gap-2">
          <span>
            Lat: <span className="font-mono">{lat}</span>
          </span>
          <span>
            Lng: <span className="font-mono">{lng}</span>
          </span>
        </div>
      </div>
    </div>
  )
}
