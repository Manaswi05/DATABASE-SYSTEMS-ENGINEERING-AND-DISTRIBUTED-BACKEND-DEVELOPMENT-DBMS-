import { Plane, Ship, Warehouse, Truck, Anchor } from 'lucide-react'

const cards = [
  {
    id: 'service-air',
    icon: Plane,
    iconBg: 'bg-blue-50',
    iconBgHover: 'group-hover:bg-blue-600',
    iconColor: 'text-blue-600',
    title: 'Air Freight',
    desc: 'Fast global air transport.',
  },
  {
    id: 'service-ocean',
    icon: Ship,
    iconBg: 'bg-indigo-50',
    iconBgHover: 'group-hover:bg-indigo-600',
    iconColor: 'text-indigo-600',
    title: 'Ocean Cargo',
    desc: 'FCL and LCL shipping.',
  },
  {
    id: 'service-warehouse',
    icon: Warehouse,
    iconBg: 'bg-cyan-50',
    iconBgHover: 'group-hover:bg-cyan-600',
    iconColor: 'text-cyan-600',
    title: 'Warehousing',
    desc: 'Secure storage solutions.',
  },
  {
    id: 'service-truck',
    icon: Truck,
    iconBg: 'bg-emerald-50',
    iconBgHover: 'group-hover:bg-emerald-600',
    iconColor: 'text-emerald-600',
    title: 'Last Mile',
    desc: 'Reliable local delivery.',
  },
  {
    id: 'service-port',
    icon: Anchor,
    iconBg: 'bg-orange-50',
    iconBgHover: 'group-hover:bg-orange-600',
    iconColor: 'text-orange-600',
    title: 'Sea Port',
    desc: 'Port ops & Shipping alliances.',
  },
]

export default function ServicesSection({ onShowService }) {
  return (
    <section id="services" className="py-20 px-4 pt-32">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Our Services</h2>
          <p className="text-slate-500 max-w-2xl mx-auto">Click on a service to learn more.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {cards.map(({ id, icon: Icon, iconBg, iconBgHover, iconColor, title, desc }) => (
            <div
              key={id}
              onClick={() => onShowService(id)}
              className="cursor-pointer bg-white p-6 rounded-xl shadow-md border border-slate-100 hover:shadow-xl hover:-translate-y-2 transition-all duration-300 group"
            >
              <div
                className={`w-14 h-14 ${iconBg} rounded-lg flex items-center justify-center mb-6 ${iconBgHover} transition-colors`}
              >
                <Icon className={`w-8 h-8 ${iconColor} group-hover:text-white transition-colors`} />
              </div>
              <h3 className="text-lg font-bold text-slate-800 mb-2">{title}</h3>
              <p className="text-slate-500 text-xs">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
