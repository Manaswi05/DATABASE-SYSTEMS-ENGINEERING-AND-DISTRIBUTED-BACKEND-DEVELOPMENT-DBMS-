import { useState } from 'react'
import { Truck } from 'lucide-react'

export default function AuthView({ isLoginMode, onToggleMode, onAuth }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    onAuth()
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-100">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden view-transition border border-slate-200">
        <div className="bg-blue-900 p-8 text-center relative overflow-hidden">
          <div
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage:
                "url('data:image/svg+xml,%3Csvg width=\\'20\\' height=\\'20\\' viewBox=\\'0 0 20 20\\' xmlns=\\'http://www.w3.org/2000/svg\\'%3E%3Cg fill=\\'%23ffffff\\' fill-opacity=\\'1\\' fill-rule=\\'evenodd\\'%3E%3Ccircle cx=\\'3\\' cy=\\'3\\' r=\\'3\\'/%3E%3Ccircle cx=\\'13\\' cy=\\'13\\' r=\\'3\\'/%3E%3C/g%3E%3C/svg%3E')",
            }}
          ></div>
          <Truck className="w-12 h-12 text-white mx-auto mb-3 relative z-10" />
          <h1 className="text-2xl font-bold text-white tracking-wide uppercase relative z-10">
            Logistics Global
          </h1>
        </div>
        <div className="p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
            {isLoginMode ? 'Welcome Back' : 'Create Account'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full rounded-lg border-gray-300 border p-2.5 focus:ring-blue-600 focus:outline-none"
                placeholder="user@logistics.com"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full rounded-lg border-gray-300 border p-2.5 focus:ring-blue-600 focus:outline-none"
                placeholder="••••••••"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-900 hover:bg-blue-800 text-white font-bold py-3 rounded-lg transition-all shadow-md"
            >
              {isLoginMode ? 'Login' : 'Sign Up'}
            </button>
          </form>
          <div className="mt-6 text-center text-sm">
            <span className="text-gray-500">
              {isLoginMode ? "Don't have an account?" : 'Already have an account?'}
            </span>
            <button
              onClick={onToggleMode}
              className="text-blue-700 font-semibold hover:underline ml-1"
            >
              {isLoginMode ? 'Sign up' : 'Login'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
