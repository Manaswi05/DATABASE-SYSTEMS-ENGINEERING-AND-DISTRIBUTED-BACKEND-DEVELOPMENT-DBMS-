import { useState } from 'react'
import { X, Check, Copy } from 'lucide-react'

const emptyForm = {
  weight: '',
  dims: '',
  content: '',
  senderName: '',
  senderAddr: '',
  senderPhone: '',
  senderEmail: '',
  receiverName: '',
  receiverAddr: '',
  receiverPhone: '',
  receiverEmail: '',
}

export default function BookingModal({ onClose, onFinish }) {
  const [step, setStep] = useState(1)
  const [form, setForm] = useState(emptyForm)
  const [generatedId, setGeneratedId] = useState('TRK-????')

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
  }

  function nextStep(s) {
    setStep(s)
  }

  function finishBooking() {
    const shipmentData = {
      weight: form.weight || '1',
      dims: form.dims || '10x10x10',
      contentType: form.content || 'General',
      senderName: form.senderName || 'Anonymous',
      senderAddr: form.senderAddr || 'Unknown Origin',
      receiverName: form.receiverName || 'Anonymous',
      receiverAddr: form.receiverAddr || 'Unknown Dest',
      status: 'Order Placed',
      timestamp: new Date().toLocaleString(),
    }
    const newId = 'TRK-' + Math.floor(100000 + Math.random() * 900000)
    onFinish(newId, shipmentData)
    setGeneratedId(newId)
    nextStep(4)
  }

  function copyToClipboard() {
    navigator.clipboard
      .writeText(generatedId)
      .then(() => alert('ID Copied: ' + generatedId))
      .catch((err) => {
        console.error('Failed to copy text: ', err)
        alert('Failed to copy ID')
      })
  }

  const progress = step * 25

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto"
      aria-labelledby="modal-title"
      role="dialog"
      aria-modal="true"
    >
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div
          className="fixed inset-0 bg-gray-900 bg-opacity-75 transition-opacity"
          onClick={onClose}
        ></div>
        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">
          &#8203;
        </span>
        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full modal-enter">
          <div className="bg-blue-900 px-4 py-3 sm:px-6 flex justify-between items-center">
            <h3 className="text-lg leading-6 font-medium text-white" id="modal-title">
              Create New Shipment
            </h3>
            <button onClick={onClose} className="text-blue-200 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="px-4 py-5 sm:p-6">
            {/* Progress Bar */}
            <div className="mb-6">
              <div className="flex items-center justify-between text-xs font-semibold text-gray-500 mb-2">
                <span className={step >= 1 ? 'text-blue-600' : ''}>Item</span>
                <span className={step >= 2 ? 'text-blue-600' : ''}>Sender</span>
                <span className={step >= 3 ? 'text-blue-600' : ''}>Receiver</span>
                <span className={step >= 4 ? 'text-blue-600' : ''}>Done</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-600 transition-all duration-300"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
            </div>

            {/* Step 1: Item Details */}
            {step === 1 && (
              <div className="space-y-4">
                <h4 className="font-bold text-gray-800 text-lg">Item Details</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Weight (kg)
                    </label>
                    <input
                      type="number"
                      value={form.weight}
                      onChange={(e) => update('weight', e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 border p-2 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      placeholder="e.g. 5"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Content Type
                    </label>
                    <input
                      type="text"
                      value={form.content}
                      onChange={(e) => update('content', e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 border p-2 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      placeholder="e.g. Books"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Dimensions (L x W x H cm)
                  </label>
                  <input
                    type="text"
                    value={form.dims}
                    onChange={(e) => update('dims', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 border p-2 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="e.g. 30 x 20 x 10"
                  />
                </div>
                <div className="flex justify-end pt-4">
                  <button
                    onClick={() => nextStep(2)}
                    className="bg-blue-900 text-white px-4 py-2 rounded-md hover:bg-blue-800"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Sender Details */}
            {step === 2 && (
              <div className="space-y-4">
                <h4 className="font-bold text-gray-800 text-lg">Sender Details (You)</h4>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Full Name</label>
                  <input
                    type="text"
                    value={form.senderName}
                    onChange={(e) => update('senderName', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 border p-2 shadow-sm"
                    placeholder="Your Name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Full Address</label>
                  <input
                    type="text"
                    value={form.senderAddr}
                    onChange={(e) => update('senderAddr', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 border p-2 shadow-sm"
                    placeholder="Area, City, State"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Phone</label>
                    <input
                      type="tel"
                      value={form.senderPhone}
                      onChange={(e) => update('senderPhone', e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 border p-2 shadow-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Email</label>
                    <input
                      type="email"
                      value={form.senderEmail}
                      onChange={(e) => update('senderEmail', e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 border p-2 shadow-sm"
                    />
                  </div>
                </div>
                <div className="flex justify-between pt-4">
                  <button onClick={() => nextStep(1)} className="text-gray-500 hover:text-gray-700">
                    Back
                  </button>
                  <button
                    onClick={() => nextStep(3)}
                    className="bg-blue-900 text-white px-4 py-2 rounded-md hover:bg-blue-800"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Receiver Details */}
            {step === 3 && (
              <div className="space-y-4">
                <h4 className="font-bold text-gray-800 text-lg">Receiver Details</h4>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Full Name</label>
                  <input
                    type="text"
                    value={form.receiverName}
                    onChange={(e) => update('receiverName', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 border p-2 shadow-sm"
                    placeholder="Receiver Name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Full Address (Destination)
                  </label>
                  <input
                    type="text"
                    value={form.receiverAddr}
                    onChange={(e) => update('receiverAddr', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 border p-2 shadow-sm"
                    placeholder="Area, City, State"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Phone</label>
                    <input
                      type="tel"
                      value={form.receiverPhone}
                      onChange={(e) => update('receiverPhone', e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 border p-2 shadow-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Email</label>
                    <input
                      type="email"
                      value={form.receiverEmail}
                      onChange={(e) => update('receiverEmail', e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 border p-2 shadow-sm"
                    />
                  </div>
                </div>
                <div className="flex justify-between pt-4">
                  <button onClick={() => nextStep(2)} className="text-gray-500 hover:text-gray-700">
                    Back
                  </button>
                  <button
                    onClick={finishBooking}
                    className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 shadow-md"
                  >
                    Create Shipment
                  </button>
                </div>
              </div>
            )}

            {/* Step 4: Success */}
            {step === 4 && (
              <div className="text-center py-6">
                <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-4">
                  <Check className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-lg leading-6 font-medium text-gray-900">
                  Shipment Created!
                </h3>
                <p className="text-sm text-gray-500 mt-2">Your package has been registered.</p>

                <div className="mt-6 bg-slate-100 p-4 rounded-lg border border-slate-200">
                  <p className="text-xs text-gray-500 uppercase font-bold">Your Package ID</p>
                  <div className="flex items-center justify-center gap-2 mt-2">
                    <span className="text-2xl font-mono font-bold text-blue-900 tracking-wider">
                      {generatedId}
                    </span>
                    <button onClick={copyToClipboard} className="text-gray-400 hover:text-blue-600">
                      <Copy className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                <p className="text-xs text-gray-400 mt-4">
                  Copy this ID to track your shipment instantly.
                </p>

                <div className="mt-6">
                  <button
                    onClick={onClose}
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-900 text-base font-medium text-white hover:bg-blue-800 sm:text-sm"
                  >
                    Done
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
