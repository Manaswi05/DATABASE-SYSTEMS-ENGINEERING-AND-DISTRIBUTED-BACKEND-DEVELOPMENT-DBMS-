import { ArrowLeft, Anchor, Container } from 'lucide-react'

const gallery = [
  { src: 'https://images.unsplash.com/photo-1516937941348-c09e55483f3b?q=80&w=2070&auto=format&fit=crop', alt: 'Ship Docking' },
  { src: 'https://images.unsplash.com/photo-1548123281-b54170e7041a?q=80&w=2070&auto=format&fit=crop', alt: 'Crane Operator' },
  { src: 'https://images.unsplash.com/photo-1618848464627-c104e76a5455?q=80&w=2070&auto=format&fit=crop', alt: 'Night Port' },
]

const collaborations = [
  { name: 'MAERSK', color: 'text-blue-900' },
  { name: 'MSC', color: 'text-yellow-600' },
  { name: 'CMA CGM', color: 'text-blue-600' },
  { name: 'EVERGREEN', color: 'text-green-700' },
]

export default function SeaPortPage({ onHome }) {
  return (
    <div className="min-h-screen flex flex-col view-transition bg-white">
      <nav className="fixed w-full z-50 bg-blue-900 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 flex justify-between h-16 items-center">
          <button
            onClick={onHome}
            className="flex items-center gap-2 hover:text-blue-200 transition-colors font-semibold"
          >
            <ArrowLeft className="w-5 h-5" /> Back to Home
          </button>
          <span className="font-bold text-lg">Sea Port Operations</span>
        </div>
      </nav>

      {/* Hero */}
      <div className="service-hero hero-port flex items-center justify-center mt-16 relative">
        <h1 className="text-5xl md:text-7xl font-black text-white drop-shadow-xl z-10 text-center px-4">
          SEA PORT &<br />ALLIANCES
        </h1>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-6">Strategic Port Partnerships</h2>
            <p className="text-lg text-slate-600 leading-relaxed mb-6">
              We manage the entire docking and handling lifecycle. Our strategic alliances with
              major global sea ports ensure priority berthing and faster customs clearance.
            </p>
            <ul className="space-y-4">
              <li className="flex items-center gap-3">
                <Anchor className="text-orange-600 w-5 h-5" />
                <span className="text-slate-700 font-medium">Priority Terminal Access</span>
              </li>
              <li className="flex items-center gap-3">
                <Container className="text-orange-600 w-5 h-5" />
                <span className="text-slate-700 font-medium">Dedicated Container Yards</span>
              </li>
            </ul>
          </div>
          <div>
            <img
              src="https://images.unsplash.com/photo-1548123281-b54170e7041a?q=80&w=2071&auto=format&fit=crop"
              className="rounded-xl shadow-2xl w-full"
              alt="Container Terminal"
            />
          </div>
        </div>

        <h3 className="text-2xl font-bold text-slate-900 mb-6">Port Operations Gallery</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-20">
          {gallery.map((img) => (
            <img
              key={img.src}
              src={img.src}
              alt={img.alt}
              className="w-full h-48 object-cover rounded-lg shadow-md hover:scale-105 transition-transform"
            />
          ))}
        </div>

        {/* Collaborations Section */}
        <div className="bg-slate-50 rounded-2xl p-10 border border-slate-200">
          <h2 className="text-3xl font-bold text-slate-900 text-center mb-4">
            Global Shipping Collaborations
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-8">
            {collaborations.map((c) => (
              <div
                key={c.name}
                className="bg-white p-6 rounded-lg shadow-sm border border-slate-100 flex flex-col items-center justify-center hover:shadow-md transition-shadow"
              >
                <div className={`text-2xl font-black ${c.color} mb-2`}>{c.name}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
