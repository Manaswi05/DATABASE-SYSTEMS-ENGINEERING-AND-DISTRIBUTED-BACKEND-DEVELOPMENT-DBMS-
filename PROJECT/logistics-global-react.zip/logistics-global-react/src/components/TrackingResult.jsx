import { Box, Navigation } from 'lucide-react'
import TrackingMap from './TrackingMap.jsx'

export default function TrackingResult({ result }) {
  if (!result) return null

  return (
    <section className="bg-slate-50 pt-24 pb-10">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              Tracking ID:{' '}
              <span className="text-blue-600 font-mono text-xl">{result.id}</span>
            </h3>
            <p className="text-sm text-slate-500">Carrier: LogisticsGlobal Express</p>
          </div>
          <span className="bg-green-100 text-green-800 text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-wide flex items-center gap-1">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span> In Transit
          </span>
        </div>

        <TrackingMap address={result.trackingLocation} />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
            <h4 className="font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
              <Box className="w-4 h-4 text-blue-500" /> Package Details
            </h4>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-500 text-sm">Weight</span>
                <span className="font-semibold text-slate-900">{result.weight}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 text-sm">Dimensions</span>
                <span className="font-semibold text-slate-900">{result.dims}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 text-sm">Sender</span>
                <span className="font-semibold text-slate-900">{result.sender}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 text-sm">Receiver</span>
                <span className="font-semibold text-slate-900">{result.receiver}</span>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
            <h4 className="font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
              <Navigation className="w-4 h-4 text-blue-500" /> Route Information
            </h4>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-500 text-sm">Origin</span>
                <span className="font-semibold text-slate-900">{result.origin}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 text-sm">Destination</span>
                <span className="font-semibold text-slate-900">{result.dest}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 text-sm">Status</span>
                <span className="font-semibold text-green-600">In Transit</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 text-sm">Last Update</span>
                <span className="font-semibold text-slate-900">Just Now</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
