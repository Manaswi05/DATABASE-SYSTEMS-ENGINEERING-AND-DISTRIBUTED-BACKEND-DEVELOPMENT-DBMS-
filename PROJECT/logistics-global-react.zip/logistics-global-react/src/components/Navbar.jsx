import { Package, LogOut } from 'lucide-react'

export default function Navbar({ onHome, onLogout }) {
  return (
    <nav className="fixed w-full z-40 bg-blue-900/95 backdrop-blur-md border-b border-blue-800 shadow-lg text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={onHome}>
            <Package className="h-6 w-6 text-blue-300" />
            <span className="font-bold text-xl tracking-wider">
              LOGISTICS<span className="text-blue-300">GLOBAL</span>
            </span>
          </div>
          <div className="hidden md:flex space-x-8">
            <a href="#tracking" className="hover:text-blue-300 transition-colors">Track</a>
            <a href="#services" className="hover:text-blue-300 transition-colors">Services</a>
            <a href="#quote" className="hover:text-blue-300 transition-colors">Get Quote</a>
            <a href="#network" className="hover:text-blue-300 transition-colors">Network</a>
          </div>
          <button
            onClick={onLogout}
            className="bg-blue-800 hover:bg-blue-700 px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>
      </div>
    </nav>
  )
}
