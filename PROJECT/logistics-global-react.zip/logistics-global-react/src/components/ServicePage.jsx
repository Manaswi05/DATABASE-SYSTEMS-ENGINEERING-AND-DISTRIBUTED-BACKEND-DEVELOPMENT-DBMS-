import { ArrowLeft } from 'lucide-react'
import { services } from '../data/services.js'

export default function ServicePage({ id, onHome }) {
  const data = services[id]
  if (!data) return null

  return (
    <div className="min-h-screen flex flex-col view-transition bg-white">
      <nav className="fixed w-full z-50 bg-blue-900 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 flex justify-between h-16 items-center">
          <button
            onClick={onHome}
            className="flex items-center gap-2 hover:text-blue-200 transition-colors font-semibold"
          >
            <ArrowLeft className="w-5 h-5" /> Back to Home
          </button>
          <span className="font-bold text-lg">{data.navTitle}</span>
        </div>
      </nav>
      <div className={`service-hero ${data.heroClass} flex items-center justify-center mt-16`}>
        <h1 className="text-5xl font-black text-white drop-shadow-lg">{data.heroTitle}</h1>
      </div>
      <div className="max-w-5xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-slate-900 mb-6">{data.heading}</h2>
        <p className="text-lg text-slate-600 leading-relaxed mb-12">{data.paragraph}</p>

        <h3 className="text-2xl font-bold text-slate-900 mb-6">Gallery</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-16">
          {data.gallery.map((img) => (
            <img
              key={img.src}
              src={img.src}
              alt={img.alt}
              className="w-full h-48 object-cover rounded-lg shadow-md hover:scale-105 transition-transform"
            />
          ))}
        </div>

        <h3 className="text-2xl font-bold text-slate-900 mb-6">{data.partnersTitle}</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {data.partners.map((p) => (
            <div
              key={p.name}
              className="bg-slate-50 p-6 rounded-lg text-center border border-slate-200"
            >
              <span className={`text-xl font-black ${p.color} partner-logo`}>{p.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
