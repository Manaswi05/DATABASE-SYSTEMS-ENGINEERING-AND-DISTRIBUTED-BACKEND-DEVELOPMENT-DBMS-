import { useState } from 'react'
import { Search, PlusCircle } from 'lucide-react'
import Navbar from './Navbar.jsx'
import TrackingResult from './TrackingResult.jsx'
import ServicesSection from './ServicesSection.jsx'
import QuoteSection from './QuoteSection.jsx'
import NetworkSection from './NetworkSection.jsx'
import Footer from './Footer.jsx'

export default function HomeView({
  onLogout,
  onHome,
  onShowService,
  onOpenBookingModal,
  shipmentDatabase,
}) {
  const [trackingId, setTrackingId] = useState('')
  const [trackingResult, setTrackingResult] = useState(null)

  function trackShipment() {
    const id = trackingId.trim()
    if (!id) {
      alert('Please enter a tracking ID')
      return
    }

    let trackingLocation = 'Mumbai, India' // Default for demo
    let data

    if (shipmentDatabase.current[id]) {
      const record = shipmentDatabase.current[id]
      data = {
        id,
        weight: record.weight + ' kg',
        dims: record.dims + ' cm',
        sender: record.senderName,
        receiver: record.receiverName,
        origin: record.senderAddr,
        dest: record.receiverAddr,
      }
      trackingLocation = record.senderAddr
    } else {
      // Fallback demo data, same as the original
      data = {
        id,
        weight: '24.5 kg',
        dims: '45 x 30 x 30 cm',
        sender: 'Logistics Corp',
        receiver: 'John Doe',
        origin: 'New Delhi, India',
        dest: 'Bangalore, India',
      }
      trackingLocation = 'Hyderabad, India' // Just a demo default
    }

    setTrackingResult({ ...data, trackingLocation })

    setTimeout(() => {
      document.getElementById('tracking-result-anchor')?.scrollIntoView({ behavior: 'smooth' })
    }, 50)
  }

  return (
    <div className="min-h-screen flex flex-col view-transition">
      <Navbar onHome={onHome} onLogout={onLogout} />

      <header className="hero-section flex items-center justify-center relative pt-16">
        <div className="text-center px-4 w-full max-w-5xl relative z-10">
          <span className="inline-block py-1 px-3 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-200 text-sm font-semibold mb-6 backdrop-blur-sm">
            Global Supply Chain Solutions
          </span>
          <h1 className="text-5xl md:text-8xl font-black text-white tracking-tighter mb-6 drop-shadow-2xl leading-tight">
            DELIVERING
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">
              THE FUTURE
            </span>
          </h1>

          <div className="mb-10">
            <button
              onClick={onOpenBookingModal}
              className="group relative px-8 py-4 bg-orange-500 hover:bg-orange-600 text-white rounded-full font-bold text-lg transition-all shadow-lg hover:shadow-orange-500/50 flex items-center gap-3 mx-auto animate-bounce"
            >
              <PlusCircle className="w-6 h-6" />
              Do you wanna transport anything?
            </button>
          </div>

          <div
            id="tracking"
            className="max-w-3xl mx-auto bg-white rounded-lg shadow-2xl p-2 flex flex-col sm:flex-row gap-2 transform translate-y-12"
          >
            <div className="flex-grow relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                value={trackingId}
                onChange={(e) => setTrackingId(e.target.value)}
                className="pl-10 block w-full h-14 rounded-md border-gray-200 bg-gray-50 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-lg"
                placeholder="Enter Tracking ID"
              />
            </div>
            <button
              onClick={trackShipment}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold h-14 px-8 rounded-md transition-colors text-lg flex items-center justify-center gap-2"
            >
              Track Cargo
            </button>
          </div>
        </div>
      </header>

      <div id="tracking-result-anchor"></div>
      <TrackingResult result={trackingResult} />

      <ServicesSection onShowService={onShowService} />
      <QuoteSection />
      <NetworkSection />
      <Footer />
    </div>
  )
}
