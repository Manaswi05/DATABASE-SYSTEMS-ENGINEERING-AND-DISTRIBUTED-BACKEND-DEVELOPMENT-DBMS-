export default function NetworkSection() {
  return (
    <section id="network" className="map-section py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-blue-900/80"></div>
      <div className="max-w-7xl mx-auto px-4 relative z-10 text-center">
        <h2 className="text-3xl font-bold text-white mb-4">Global Network</h2>
        <div className="relative w-full max-w-4xl mx-auto aspect-[2/1] bg-white/5 rounded-2xl border border-white/10 backdrop-blur-sm shadow-2xl mt-8">
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/8/80/World_map_-_low_resolution.svg"
            className="absolute inset-0 w-full h-full object-cover opacity-20 invert"
            alt="World Map"
          />
          <div className="map-dot top-[30%] left-[23%]"></div>
          <div className="map-dot top-[35%] left-[48%]"></div>
          <div className="map-dot top-[55%] left-[75%]"></div>
        </div>
      </div>
    </section>
  )
}
