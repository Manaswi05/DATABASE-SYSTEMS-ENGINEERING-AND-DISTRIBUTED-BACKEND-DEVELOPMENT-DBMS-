export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 text-center">
        &copy; 2023 Logistics Global Inc. All rights reserved.
      </div>
    </footer>
  )
}
