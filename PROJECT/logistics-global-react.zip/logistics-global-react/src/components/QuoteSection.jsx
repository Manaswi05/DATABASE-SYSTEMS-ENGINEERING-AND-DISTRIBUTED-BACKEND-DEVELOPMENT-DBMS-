import { useState } from 'react'
import { Check } from 'lucide-react'

export default function QuoteSection() {
  const [weight, setWeight] = useState(10)
  const [type, setType] = useState('1')
  const [result, setResult] = useState('₹6,000.00')

  function calculateQuote() {
    const w = parseFloat(weight) || 0
    const typeMultiplier = parseFloat(type)
    const total = (2000 + w * 200) * typeMultiplier
    setResult('₹' + total.toLocaleString('en-IN', { minimumFractionDigits: 2 }))
  }

  return (
    <section id="quote" className="py-20 bg-slate-100">
      <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row gap-12 items-center">
        <div className="md:w-1/2">
          <h2 className="text-4xl font-bold text-slate-900 mb-6">Get an Instant Quote</h2>
          <p className="text-slate-600 mb-8 text-lg">
            Calculate your shipping costs in seconds.
          </p>
          <ul className="space-y-4">
            <li className="flex items-center gap-3">
              <div className="bg-blue-200 p-1 rounded-full">
                <Check className="w-4 h-4 text-blue-800" />
              </div>
              <span className="text-slate-700">Transparent pricing in INR (₹)</span>
            </li>
          </ul>
        </div>
        <div className="md:w-1/2 w-full">
          <div className="bg-white p-8 rounded-2xl shadow-xl border border-slate-200">
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Origin</label>
                <select className="w-full rounded-md border-gray-300 p-2.5 bg-gray-50 text-sm">
                  <option value="1">Mumbai, IN</option>
                  <option value="2">New Delhi, IN</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Destination
                </label>
                <select className="w-full rounded-md border-gray-300 p-2.5 bg-gray-50 text-sm">
                  <option value="2">New Delhi, IN</option>
                  <option value="1">Mumbai, IN</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Weight (kg)
                </label>
                <input
                  type="number"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  className="w-full rounded-md border-gray-300 p-2.5 bg-gray-50 text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Transport
                </label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  className="w-full rounded-md border-gray-300 p-2.5 bg-gray-50 text-sm"
                >
                  <option value="1">Standard Ground</option>
                  <option value="3">Express Air</option>
                </select>
              </div>
            </div>
            <div className="border-t border-slate-100 pt-6 mt-6">
              <div className="flex justify-between items-center mb-6">
                <span className="text-slate-500 font-medium">Estimated Cost:</span>
                <span className="text-3xl font-bold text-blue-900">{result}</span>
              </div>
              <button
                onClick={calculateQuote}
                className="w-full bg-blue-900 hover:bg-blue-800 text-white font-bold py-3 rounded-lg transition-colors"
              >
                Recalculate Quote
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
